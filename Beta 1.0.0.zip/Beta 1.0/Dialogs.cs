using System;
using System.Drawing;
using System.Windows.Forms;

namespace InternetExplorerReborn
{
    internal sealed class InternetOptionsForm : Form
    {
        private readonly TextBox homePageBox;
        private readonly CheckBox modernModeCheckBox;
        private readonly string currentAddress;

        public InternetOptionsForm(string currentHomePage, string currentPageAddress, bool modernModeEnabled)
        {
            currentAddress = currentPageAddress;
            Text = "Internet Options";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(420, 210);
            Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point);

            var label = new Label
            {
                AutoSize = true,
                Location = new Point(14, 18),
                Text = "Home page"
            };

            homePageBox = new TextBox
            {
                Location = new Point(17, 40),
                Size = new Size(385, 22),
                Text = currentHomePage
            };

            var helper = new Label
            {
                AutoSize = true,
                Location = new Point(14, 72),
                Text = "Choose the page that opens when the Home button is clicked."
            };

            modernModeCheckBox = new CheckBox
            {
                AutoSize = true,
                Location = new Point(17, 104),
                Text = "Modern Mode",
                Checked = modernModeEnabled
            };

            var modernModeHelper = new Label
            {
                AutoSize = true,
                Location = new Point(34, 126),
                Text = "Open pages in Microsoft Edge for better compatibility."
            };

            var useCurrentButton = new Button
            {
                Text = "Use Current",
                Location = new Point(17, 154),
                Size = new Size(95, 26)
            };
            useCurrentButton.Click += UseCurrentButtonOnClick;

            var okButton = new Button
            {
                Text = "OK",
                DialogResult = DialogResult.OK,
                Location = new Point(226, 154),
                Size = new Size(82, 26)
            };
            okButton.Click += OkButtonOnClick;

            var cancelButton = new Button
            {
                Text = "Cancel",
                DialogResult = DialogResult.Cancel,
                Location = new Point(320, 154),
                Size = new Size(82, 26)
            };

            Controls.Add(label);
            Controls.Add(homePageBox);
            Controls.Add(helper);
            Controls.Add(modernModeCheckBox);
            Controls.Add(modernModeHelper);
            Controls.Add(useCurrentButton);
            Controls.Add(okButton);
            Controls.Add(cancelButton);

            AcceptButton = okButton;
            CancelButton = cancelButton;
        }

        public string HomePage
        {
            get { return homePageBox.Text.Trim(); }
        }

        public bool ModernModeEnabled
        {
            get { return modernModeCheckBox.Checked; }
        }

        private void UseCurrentButtonOnClick(object sender, EventArgs eventArgs)
        {
            homePageBox.Text = currentAddress;
        }

        private void OkButtonOnClick(object sender, EventArgs eventArgs)
        {
            if (string.IsNullOrWhiteSpace(HomePage))
            {
                MessageBox.Show(this, "Please enter a home page.", "Internet Options", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.None;
            }
        }
    }

    internal sealed class AddFavoriteForm : Form
    {
        private readonly TextBox titleBox;
        private readonly TextBox urlBox;

        public AddFavoriteForm(string defaultTitle, string defaultUrl)
        {
            Text = "Add to Favorites";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(430, 180);
            Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point);

            var titleLabel = new Label
            {
                AutoSize = true,
                Location = new Point(14, 18),
                Text = "Name"
            };

            titleBox = new TextBox
            {
                Location = new Point(17, 38),
                Size = new Size(395, 22),
                Text = defaultTitle
            };

            var urlLabel = new Label
            {
                AutoSize = true,
                Location = new Point(14, 74),
                Text = "Address"
            };

            urlBox = new TextBox
            {
                Location = new Point(17, 94),
                Size = new Size(395, 22),
                Text = defaultUrl
            };

            var okButton = new Button
            {
                Text = "Add",
                DialogResult = DialogResult.OK,
                Location = new Point(244, 132),
                Size = new Size(80, 26)
            };
            okButton.Click += OkButtonOnClick;

            var cancelButton = new Button
            {
                Text = "Cancel",
                DialogResult = DialogResult.Cancel,
                Location = new Point(332, 132),
                Size = new Size(80, 26)
            };

            Controls.Add(titleLabel);
            Controls.Add(titleBox);
            Controls.Add(urlLabel);
            Controls.Add(urlBox);
            Controls.Add(okButton);
            Controls.Add(cancelButton);

            AcceptButton = okButton;
            CancelButton = cancelButton;
        }

        public string FavoriteTitle
        {
            get { return titleBox.Text.Trim(); }
        }

        public string FavoriteUrl
        {
            get { return urlBox.Text.Trim(); }
        }

        private void OkButtonOnClick(object sender, EventArgs eventArgs)
        {
            if (string.IsNullOrWhiteSpace(FavoriteTitle) || string.IsNullOrWhiteSpace(FavoriteUrl))
            {
                MessageBox.Show(this, "Please enter both a name and an address.", "Favorites", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.None;
            }
        }
    }

    internal sealed class FavoritesManagerForm : Form
    {
        private readonly AppSettings settings;
        private readonly ListBox favoritesList;

        public FavoritesManagerForm(AppSettings appSettings)
        {
            settings = appSettings;

            Text = "Organize Favorites";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(430, 260);
            Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point);

            favoritesList = new ListBox
            {
                Location = new Point(16, 16),
                Size = new Size(300, 200)
            };

            var removeButton = new Button
            {
                Text = "Remove",
                Location = new Point(330, 16),
                Size = new Size(84, 28)
            };
            removeButton.Click += RemoveButtonOnClick;

            var closeButton = new Button
            {
                Text = "Close",
                DialogResult = DialogResult.OK,
                Location = new Point(330, 188),
                Size = new Size(84, 28)
            };

            Controls.Add(favoritesList);
            Controls.Add(removeButton);
            Controls.Add(closeButton);

            AcceptButton = closeButton;
            RefreshFavorites();
        }

        private void RefreshFavorites()
        {
            favoritesList.Items.Clear();
            foreach (var favorite in settings.Favorites)
            {
                favoritesList.Items.Add(favorite.Title + " | " + favorite.Url);
            }
        }

        private void RemoveButtonOnClick(object sender, EventArgs eventArgs)
        {
            if (favoritesList.SelectedIndex < 0 || favoritesList.SelectedIndex >= settings.Favorites.Count)
            {
                return;
            }

            settings.Favorites.RemoveAt(favoritesList.SelectedIndex);
            RefreshFavorites();
        }
    }
}
