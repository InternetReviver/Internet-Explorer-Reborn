using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace InternetExplorerReborn
{
    [Serializable]
    public sealed class AppSettings
    {
        public string HomePage { get; set; }

        public bool ModernMode { get; set; }

        public List<FavoriteEntry> Favorites { get; set; }

        public AppSettings()
        {
            Favorites = new List<FavoriteEntry>();
        }

        public static AppSettings Load(string path)
        {
            try
            {
                if (!File.Exists(path))
                {
                    return new AppSettings();
                }

                var serializer = new XmlSerializer(typeof(AppSettings));
                using (var stream = File.OpenRead(path))
                {
                    var loaded = serializer.Deserialize(stream) as AppSettings;
                    if (loaded == null)
                    {
                        return new AppSettings();
                    }

                    if (loaded.Favorites == null)
                    {
                        loaded.Favorites = new List<FavoriteEntry>();
                    }

                    return loaded;
                }
            }
            catch
            {
                return new AppSettings();
            }
        }

        public void Save(string path)
        {
            var serializer = new XmlSerializer(typeof(AppSettings));
            using (var stream = File.Create(path))
            {
                serializer.Serialize(stream, this);
            }
        }

        public void AddOrUpdateFavorite(string title, string url)
        {
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(url))
            {
                return;
            }

            var existing = Favorites.FirstOrDefault(
                delegate(FavoriteEntry entry)
                {
                    return string.Equals(entry.Url, url, StringComparison.OrdinalIgnoreCase);
                });

            if (existing != null)
            {
                existing.Title = title.Trim();
                return;
            }

            Favorites.Add(new FavoriteEntry
            {
                Title = title.Trim(),
                Url = url.Trim()
            });
        }
    }

    [Serializable]
    public sealed class FavoriteEntry
    {
        public string Title { get; set; }

        public string Url { get; set; }
    }
}
