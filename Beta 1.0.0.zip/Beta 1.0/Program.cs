using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace InternetExplorerReborn
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += OnThreadException;
                AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;

                BrowserFeatureControl.EnableForExecutable();
                Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                LogStartupException(ex);
                MessageBox.Show(
                    "Internet Explorer REBORN could not start.\n\nDetails were written to startup-error.log",
                    "Startup Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private static void OnThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            LogStartupException(e.Exception);
        }

        private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var exception = e.ExceptionObject as Exception;
            if (exception != null)
            {
                LogStartupException(exception);
            }
        }

        private static void LogStartupException(Exception ex)
        {
            try
            {
                var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "startup-error.log");
                File.WriteAllText(path, DateTime.Now.ToString("u") + Environment.NewLine + ex);
            }
            catch
            {
            }
        }
    }

    internal static class BrowserFeatureControl
    {
        private const string BrowserEmulationKey = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION";
        private const string GpuRenderingKey = @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_GPU_RENDERING";
        private const int Ie11EdgeMode = 11001;

        public static void EnableForExecutable()
        {
            var executableName = Path.GetFileName(Application.ExecutablePath);
            if (string.IsNullOrWhiteSpace(executableName))
            {
                return;
            }

            TrySetFeature(BrowserEmulationKey, executableName, Ie11EdgeMode);
            TrySetFeature(GpuRenderingKey, executableName, 1);
        }

        private static void TrySetFeature(string keyPath, string executableName, int value)
        {
            try
            {
                using (var key = Registry.CurrentUser.CreateSubKey(keyPath))
                {
                    if (key == null)
                    {
                        return;
                    }

                    key.SetValue(executableName, value, RegistryValueKind.DWord);
                }
            }
            catch
            {
                // Best effort only. The browser can still run without these feature controls.
            }
        }
    }
}
