$ErrorActionPreference = "Stop"

$frameworkDir = if (Test-Path "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe") {
    "C:\Windows\Microsoft.NET\Framework64\v4.0.30319"
} else {
    "C:\Windows\Microsoft.NET\Framework\v4.0.30319"
}

$outputDir = Join-Path $PSScriptRoot "build"
if (-not (Test-Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir | Out-Null
}

$iconSource = "D:\Untitled.jpg"
$iconOutput = Join-Path $outputDir "app.ico"

$sources = @(
    (Join-Path $PSScriptRoot "AppSettings.cs"),
    (Join-Path $PSScriptRoot "Dialogs.cs"),
    (Join-Path $PSScriptRoot "Program.cs"),
    (Join-Path $PSScriptRoot "MainForm.cs")
)

$references = @(
    (Join-Path $frameworkDir "System.dll"),
    (Join-Path $frameworkDir "System.Drawing.dll"),
    (Join-Path $frameworkDir "System.Windows.Forms.dll"),
    "C:\Program Files\Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\Microsoft.Web.WebView2.Core.dll",
    "C:\Program Files\Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\Microsoft.Web.WebView2.WinForms.dll"
)

$compiler = Join-Path $frameworkDir "csc.exe"
$manifest = Join-Path $PSScriptRoot "app.manifest"
$output = Join-Path $outputDir "Internet Explorer REBORN.exe"
$legacyOutput = Join-Path $outputDir "Internet Explorer REBORN 1.0.exe"

if (Test-Path $iconSource) {
    Add-Type -AssemblyName System.Drawing

    $bitmap = [System.Drawing.Bitmap]::FromFile($iconSource)
    try {
        $canvas = New-Object System.Drawing.Bitmap 256, 256, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
        try {
            $canvas.MakeTransparent([System.Drawing.Color]::White)
            $graphics = [System.Drawing.Graphics]::FromImage($canvas)
            try {
                $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                $graphics.Clear([System.Drawing.Color]::Transparent)
                $graphics.DrawImage($bitmap, 0, 0, 256, 256)
                $canvas.MakeTransparent([System.Drawing.Color]::White)

                $icon = [System.Drawing.Icon]::FromHandle($canvas.GetHicon())
                try {
                    $stream = [System.IO.File]::Create($iconOutput)
                    try {
                        $icon.Save($stream)
                    }
                    finally {
                        $stream.Dispose()
                    }
                }
                finally {
                    $icon.Dispose()
                }
            }
            finally {
                $graphics.Dispose()
            }
        }
        finally {
            $canvas.Dispose()
        }
    }
    finally {
        $bitmap.Dispose()
    }
}

& $compiler `
    /nologo `
    /target:winexe `
    /optimize+ `
    /win32manifest:$manifest `
    /win32icon:$iconOutput `
    /out:$output `
    /r:$($references -join ",") `
    $sources

if ($LASTEXITCODE -ne 0) {
    throw "Compilation failed."
}

Copy-Item "C:\Program Files\Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\Microsoft.Web.WebView2.Core.dll" $outputDir -Force
Copy-Item "C:\Program Files\Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\Microsoft.Web.WebView2.WinForms.dll" $outputDir -Force
Copy-Item "C:\Program Files\Microsoft Office\root\Office16\ADDINS\Microsoft Power Query for Excel Integrated\bin\WebView2Loader.dll" $outputDir -Force
Copy-Item -Path $output -Destination $legacyOutput -Force

Write-Host "Built:" $output
