using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace InternetExplorerReborn
{
    public sealed class MainForm : Form
    {
        private readonly MenuStrip menuStrip;
        private readonly ToolStrip toolStrip;
        private readonly ToolStripButton backButton;
        private readonly ToolStripButton forwardButton;
        private readonly ToolStripButton stopButton;
        private readonly ToolStripButton refreshButton;
        private readonly ToolStripButton homeButton;
        private readonly ToolStripLabel addressLabel;
        private readonly ToolStripTextBox addressBox;
        private readonly ToolStripButton goButton;
        private readonly StatusStrip statusStrip;
        private readonly ToolStripStatusLabel statusLabel;
        private readonly ToolStripProgressBar progressBar;
        private readonly TabControl tabControl;
        private readonly TabPage legacyTabPage;
        private readonly WebBrowser browser;
        private readonly ToolStripMenuItem favoritesMenu;
        private readonly AppSettings settings;
        private readonly string settingsPath;

        private const string DefaultHomePage = "https://www.bing.com/";
        private const string VersionLabel = "Internet explorer REBORN 1.0 FOUNDATION edition";

        public MainForm()
        {
            settingsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "settings.xml");
            settings = AppSettings.Load(settingsPath);
            if (string.IsNullOrWhiteSpace(settings.HomePage))
            {
                settings.HomePage = DefaultHomePage;
            }

            Text = "Windows Internet Explorer";
            StartPosition = FormStartPosition.CenterScreen;
            ShowInTaskbar = true;
            WindowState = FormWindowState.Normal;
            MinimumSize = new Size(900, 640);
            Size = new Size(1180, 820);
            Font = new Font("Tahoma", 8.25f, FontStyle.Regular, GraphicsUnit.Point);
            BackColor = Color.FromArgb(236, 233, 216);
            Icon = SystemIcons.Application;

            favoritesMenu = new ToolStripMenuItem("F&avorites");
            menuStrip = BuildMenu();
            toolStrip = new ToolStrip();
            backButton = BuildButton("Back", NavigateBack);
            forwardButton = BuildButton("Forward", NavigateForward);
            stopButton = BuildButton("Stop", StopNavigation);
            refreshButton = BuildButton("Refresh", RefreshPage);
            homeButton = BuildButton("Home", GoHome);
            addressLabel = new ToolStripLabel("Address");
            addressBox = new ToolStripTextBox();
            goButton = BuildButton("Go", NavigateFromAddressBar);
            statusStrip = new StatusStrip();
            statusLabel = new ToolStripStatusLabel();
            progressBar = new ToolStripProgressBar();
            tabControl = new TabControl();
            legacyTabPage = new TabPage("Internet");
            browser = new WebBrowser();

            SuspendLayout();
            ConfigureToolStrip();
            ConfigureStatusStrip();
            ConfigureTabControl();
            ConfigureBrowser();

            Controls.Add(tabControl);
            Controls.Add(statusStrip);
            Controls.Add(toolStrip);
            Controls.Add(menuStrip);

            MainMenuStrip = menuStrip;

            Load += OnLoad;
            Shown += OnShown;
            ResumeLayout(performLayout: false);
            PerformLayout();
        }

        private MenuStrip BuildMenu()
        {
            var strip = new MenuStrip
            {
                Dock = DockStyle.Top,
                BackColor = Color.Transparent,
                GripStyle = ToolStripGripStyle.Visible,
                RenderMode = ToolStripRenderMode.Professional,
                Renderer = new InternetExplorerRenderer()
            };

            var fileMenu = new ToolStripMenuItem("&File");
            fileMenu.DropDownItems.Add("New &Window", null, delegate { OpenHomeInNewWindow(); });
            fileMenu.DropDownItems.Add("&Open...", null, delegate { FocusAddressBar(); });
            fileMenu.DropDownItems.Add("-");
            fileMenu.DropDownItems.Add("&Close", null, delegate { Close(); });

            var editMenu = new ToolStripMenuItem("&Edit");
            editMenu.DropDownItems.Add("Cu&t", null, delegate { ExecuteDocumentCommand("Cut"); });
            editMenu.DropDownItems.Add("&Copy", null, delegate { ExecuteDocumentCommand("Copy"); });
            editMenu.DropDownItems.Add("&Paste", null, delegate { ExecuteDocumentCommand("Paste"); });
            editMenu.DropDownItems.Add("-");
            editMenu.DropDownItems.Add("Select &All", null, delegate { ExecuteDocumentCommand("SelectAll"); });

            var viewMenu = new ToolStripMenuItem("&View");
            viewMenu.DropDownItems.Add("&Refresh", null, delegate { RefreshPage(null, EventArgs.Empty); });
            viewMenu.DropDownItems.Add("&Status Bar", null, delegate { statusStrip.Visible = !statusStrip.Visible; });
            viewMenu.DropDownItems.Add("&Explorer Bar", null, delegate { ShowInfo("Explorer Bar", "Classic explorer bars are decorative in this recreation."); });

            favoritesMenu.DropDownItems.Add("Add to Favorites...", null, AddCurrentPageToFavorites);
            favoritesMenu.DropDownItems.Add("Organize Favorites...", null, ShowOrganizeFavorites);
            favoritesMenu.DropDownItems.Add("-");

            var toolsMenu = new ToolStripMenuItem("&Tools");
            toolsMenu.DropDownItems.Add("&Internet Options...", null, ShowInternetOptions);

            var settingsMenu = new ToolStripMenuItem("&Settings");
            settingsMenu.Click += ShowInternetOptions;

            var helpMenu = new ToolStripMenuItem("&Help");
            helpMenu.DropDownItems.Add("&About Internet Explorer", null, delegate { ShowAbout(); });

            strip.Items.Add(fileMenu);
            strip.Items.Add(editMenu);
            strip.Items.Add(viewMenu);
            strip.Items.Add(favoritesMenu);
            strip.Items.Add(toolsMenu);
            strip.Items.Add(settingsMenu);
            strip.Items.Add(helpMenu);

            RefreshFavoritesMenu();

            return strip;
        }

        private void ConfigureToolStrip()
        {
            toolStrip.Dock = DockStyle.Top;
            toolStrip.Location = new Point(0, menuStrip.Height);
            toolStrip.GripStyle = ToolStripGripStyle.Visible;
            toolStrip.RenderMode = ToolStripRenderMode.Professional;
            toolStrip.Renderer = new InternetExplorerRenderer();
            toolStrip.BackColor = Color.Transparent;
            toolStrip.ImageScalingSize = new Size(16, 16);
            toolStrip.Padding = new Padding(4, 2, 4, 3);
            toolStrip.CanOverflow = false;

            addressBox.AutoSize = false;
            addressBox.Size = new Size(440, 24);
            addressBox.BorderStyle = BorderStyle.FixedSingle;
            addressBox.KeyDown += AddressBoxOnKeyDown;

            addressLabel.Margin = new Padding(6, 1, 4, 2);
            toolStrip.Items.Add(backButton);
            toolStrip.Items.Add(forwardButton);
            toolStrip.Items.Add(stopButton);
            toolStrip.Items.Add(refreshButton);
            toolStrip.Items.Add(homeButton);
            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(addressLabel);
            toolStrip.Items.Add(addressBox);
            toolStrip.Items.Add(goButton);
        }

        private void ConfigureStatusStrip()
        {
            statusStrip.Dock = DockStyle.Bottom;
            statusStrip.SizingGrip = true;
            statusStrip.RenderMode = ToolStripRenderMode.Professional;
            statusStrip.Renderer = new InternetExplorerRenderer();
            statusStrip.BackColor = Color.FromArgb(236, 233, 216);

            statusLabel.Text = "Done";
            statusLabel.Spring = true;
            statusLabel.TextAlign = ContentAlignment.MiddleLeft;

            progressBar.Style = ProgressBarStyle.Continuous;
            progressBar.Size = new Size(140, 16);
            progressBar.Visible = false;

            statusStrip.Items.Add(statusLabel);
            statusStrip.Items.Add(progressBar);
        }

        private void ConfigureBrowser()
        {
            browser.Dock = DockStyle.Fill;
            browser.MinimumSize = new Size(20, 20);
            browser.ScriptErrorsSuppressed = true;
            browser.AllowWebBrowserDrop = false;
            browser.Navigated += BrowserOnNavigated;
            browser.Navigating += BrowserOnNavigating;
            browser.DocumentCompleted += BrowserOnDocumentCompleted;
            browser.ProgressChanged += BrowserOnProgressChanged;
            browser.StatusTextChanged += BrowserOnStatusTextChanged;
            browser.CanGoBackChanged += BrowserButtonsOnAvailabilityChanged;
            browser.CanGoForwardChanged += BrowserButtonsOnAvailabilityChanged;
            browser.NewWindow += BrowserOnNewWindow;

            legacyTabPage.Controls.Add(browser);
        }

        private void ConfigureTabControl()
        {
            tabControl.Dock = DockStyle.Fill;
            tabControl.DrawMode = TabDrawMode.Normal;
            tabControl.Multiline = false;
            tabControl.SelectedIndexChanged += TabControlOnSelectedIndexChanged;
            tabControl.Controls.Add(legacyTabPage);
        }

        private ToolStripButton BuildButton(string text, EventHandler onClick)
        {
            var button = new ToolStripButton(text)
            {
                DisplayStyle = ToolStripItemDisplayStyle.Text,
                AutoSize = false,
                Width = 62,
                Margin = new Padding(1, 1, 1, 2)
            };

            button.Click += onClick;
            return button;
        }

        private void OnLoad(object sender, EventArgs eventArgs)
        {
            NavigateTo(settings.HomePage);
        }

        private void OnShown(object sender, EventArgs eventArgs)
        {
            WindowState = FormWindowState.Normal;
            Show();
            Activate();
            BringToFront();
        }

        private void AddressBoxOnKeyDown(object sender, KeyEventArgs eventArgs)
        {
            if (eventArgs.KeyCode != Keys.Enter)
            {
                return;
            }

            eventArgs.SuppressKeyPress = true;
            NavigateFromAddressBar(sender, EventArgs.Empty);
        }

        private void NavigateFromAddressBar(object sender, EventArgs eventArgs)
        {
            NavigateTo(addressBox.Text);
        }

        private void NavigateTo(string rawAddress)
        {
            if (string.IsNullOrWhiteSpace(rawAddress))
            {
                return;
            }

            var candidate = rawAddress.Trim();
            Uri uri;
            if (TryBuildUri(candidate, out uri))
            {
                if (settings.ModernMode)
                {
                    OpenModernTab(uri);
                }
                else
                {
                    try
                    {
                        browser.Navigate(uri);
                    }
                    catch (Exception ex)
                    {
                        ShowInfo("Navigation Error", ex.Message);
                    }
                }

                return;
            }

            var searchUrl = "https://www.bing.com/search?q=" + Uri.EscapeDataString(candidate);
            if (settings.ModernMode)
            {
                Uri searchUri;
                if (Uri.TryCreate(searchUrl, UriKind.Absolute, out searchUri))
                {
                    OpenModernTab(searchUri);
                    return;
                }
            }

            browser.Navigate(searchUrl);
        }

        private void NavigateBack(object sender, EventArgs eventArgs)
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null && modernBrowser.CoreWebView2 != null && modernBrowser.CoreWebView2.CanGoBack)
            {
                modernBrowser.CoreWebView2.GoBack();
                return;
            }

            if (tabControl.SelectedTab == legacyTabPage && browser.CanGoBack)
            {
                browser.GoBack();
            }
        }

        private void NavigateForward(object sender, EventArgs eventArgs)
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null && modernBrowser.CoreWebView2 != null && modernBrowser.CoreWebView2.CanGoForward)
            {
                modernBrowser.CoreWebView2.GoForward();
                return;
            }

            if (tabControl.SelectedTab == legacyTabPage && browser.CanGoForward)
            {
                browser.GoForward();
            }
        }

        private void StopNavigation(object sender, EventArgs eventArgs)
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null && modernBrowser.CoreWebView2 != null)
            {
                modernBrowser.CoreWebView2.Stop();
            }
            else
            {
                browser.Stop();
            }

            statusLabel.Text = "Stopped";
            progressBar.Visible = false;
        }

        private void RefreshPage(object sender, EventArgs eventArgs)
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null && modernBrowser.CoreWebView2 != null)
            {
                modernBrowser.Reload();
                return;
            }

            browser.Refresh(WebBrowserRefreshOption.Completely);
        }

        private void GoHome(object sender, EventArgs eventArgs)
        {
            NavigateTo(settings.HomePage);
        }

        private void OpenHomeInNewWindow()
        {
            var window = new MainForm();
            window.Show();
            window.NavigateTo(settings.HomePage);
        }

        private void FocusAddressBar()
        {
            addressBox.Focus();
            addressBox.SelectAll();
        }

        private void BrowserOnNavigating(object sender, WebBrowserNavigatingEventArgs eventArgs)
        {
            statusLabel.Text = "Opening page...";
            progressBar.Value = 0;
            progressBar.Visible = true;
        }

        private void BrowserOnNavigated(object sender, WebBrowserNavigatedEventArgs eventArgs)
        {
            addressBox.Text = browser.Url != null ? browser.Url.ToString() : string.Empty;
            UpdateNavButtons();
        }

        private void BrowserOnDocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs eventArgs)
        {
            if (browser.ReadyState != WebBrowserReadyState.Complete)
            {
                return;
            }

            Text = string.IsNullOrWhiteSpace(browser.DocumentTitle)
                ? "Windows Internet Explorer"
                : browser.DocumentTitle + " - Windows Internet Explorer";

            statusLabel.Text = "Done";
            progressBar.Value = 0;
            progressBar.Visible = false;
            UpdateNavButtons();
        }

        private void BrowserOnProgressChanged(object sender, WebBrowserProgressChangedEventArgs eventArgs)
        {
            if (eventArgs.MaximumProgress <= 0 || eventArgs.CurrentProgress < 0)
            {
                progressBar.Visible = false;
                return;
            }

            progressBar.Visible = true;

            var progress = (int)Math.Min(100, Math.Max(0, eventArgs.CurrentProgress * 100L / eventArgs.MaximumProgress));
            progressBar.Value = progress;
        }

        private void BrowserOnStatusTextChanged(object sender, EventArgs eventArgs)
        {
            if (!string.IsNullOrWhiteSpace(browser.StatusText))
            {
                statusLabel.Text = browser.StatusText;
            }
        }

        private void BrowserButtonsOnAvailabilityChanged(object sender, EventArgs eventArgs)
        {
            UpdateNavButtons();
        }

        private void BrowserOnNewWindow(object sender, CancelEventArgs eventArgs)
        {
            eventArgs.Cancel = true;

            try
            {
                var activeElement = browser.Document != null ? browser.Document.ActiveElement : null;
                var href = activeElement != null ? activeElement.GetAttribute("href") : null;
                if (!string.IsNullOrWhiteSpace(href))
                {
                    NavigateTo(href);
                }
            }
            catch
            {
                // Ignore pop-up navigation failures.
            }
        }

        private void UpdateNavButtons()
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null && modernBrowser.CoreWebView2 != null)
            {
                backButton.Enabled = modernBrowser.CoreWebView2.CanGoBack;
                forwardButton.Enabled = modernBrowser.CoreWebView2.CanGoForward;
                return;
            }

            backButton.Enabled = browser.CanGoBack;
            forwardButton.Enabled = browser.CanGoForward;
        }

        private void ShowInternetOptions(object sender, EventArgs eventArgs)
        {
            using (var dialog = new InternetOptionsForm(settings.HomePage, GetCurrentAddress(), settings.ModernMode))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                settings.HomePage = dialog.HomePage;
                settings.ModernMode = dialog.ModernModeEnabled;
                settings.Save(settingsPath);
            }
        }

        private void AddCurrentPageToFavorites(object sender, EventArgs eventArgs)
        {
            var pageUrl = browser.Url != null ? browser.Url.ToString() : string.Empty;
            var pageTitle = string.IsNullOrWhiteSpace(browser.DocumentTitle) ? pageUrl : browser.DocumentTitle;

            using (var dialog = new AddFavoriteForm(pageTitle, pageUrl))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                settings.AddOrUpdateFavorite(dialog.FavoriteTitle, dialog.FavoriteUrl);
                settings.Save(settingsPath);
                RefreshFavoritesMenu();
            }
        }

        private void ShowOrganizeFavorites(object sender, EventArgs eventArgs)
        {
            using (var dialog = new FavoritesManagerForm(settings))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                settings.Save(settingsPath);
                RefreshFavoritesMenu();
            }
        }

        private void RefreshFavoritesMenu()
        {
            while (favoritesMenu.DropDownItems.Count > 3)
            {
                favoritesMenu.DropDownItems.RemoveAt(3);
            }

            if (settings.Favorites.Count == 0)
            {
                var emptyItem = new ToolStripMenuItem("(Empty)");
                emptyItem.Enabled = false;
                favoritesMenu.DropDownItems.Add(emptyItem);
                return;
            }

            foreach (var favorite in settings.Favorites)
            {
                var item = new ToolStripMenuItem(favorite.Title);
                item.Tag = favorite.Url;
                item.Click += OpenFavorite;
                favoritesMenu.DropDownItems.Add(item);
            }
        }

        private void OpenFavorite(object sender, EventArgs eventArgs)
        {
            var item = sender as ToolStripMenuItem;
            if (item == null || item.Tag == null)
            {
                return;
            }

            NavigateTo(item.Tag.ToString());
        }

        private static bool TryBuildUri(string input, out Uri uri)
        {
            if (Uri.TryCreate(input, UriKind.Absolute, out uri))
            {
                return true;
            }

            if (LooksLikeLocalFile(input))
            {
                var localPath = input;
                if (Uri.TryCreate(localPath, UriKind.Absolute, out uri))
                {
                    return true;
                }

                if (System.IO.File.Exists(localPath))
                {
                    uri = new Uri(localPath);
                    return true;
                }
            }

            if (LooksLikeHostName(input))
            {
                return Uri.TryCreate("https://" + input, UriKind.Absolute, out uri);
            }

            uri = null;
            return false;
        }

        private string GetCurrentAddress()
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null)
            {
                return modernBrowser.Source != null ? modernBrowser.Source.ToString() : settings.HomePage;
            }

            return browser.Url != null ? browser.Url.ToString() : settings.HomePage;
        }

        private async void OpenModernTab(Uri uri)
        {
            var pageTitle = "Modern Tab";
            var tabPage = new TabPage(pageTitle);
            var modernBrowser = new WebView2
            {
                Dock = DockStyle.Fill,
                Tag = uri
            };

            modernBrowser.NavigationStarting += ModernBrowserOnNavigationStarting;
            modernBrowser.NavigationCompleted += ModernBrowserOnNavigationCompleted;
            modernBrowser.SourceChanged += ModernBrowserOnSourceChanged;
            modernBrowser.CoreWebView2InitializationCompleted += ModernBrowserOnInitializationCompleted;

            tabPage.Controls.Add(modernBrowser);
            tabControl.TabPages.Add(tabPage);
            tabControl.SelectedTab = tabPage;
            statusLabel.Text = "Opening modern tab...";

            try
            {
                await modernBrowser.EnsureCoreWebView2Async(null);
                modernBrowser.Source = uri;
            }
            catch (Exception ex)
            {
                tabControl.TabPages.Remove(tabPage);
                modernBrowser.Dispose();
                ShowInfo("Modern Mode", "Unable to create a Chromium tab.\n\n" + ex.Message);
                statusLabel.Text = "Modern Mode unavailable";
            }
        }

        private void ModernBrowserOnInitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs eventArgs)
        {
            if (!eventArgs.IsSuccess)
            {
                statusLabel.Text = "Modern Mode unavailable";
                if (eventArgs.InitializationException != null)
                {
                    ShowInfo("Modern Mode", eventArgs.InitializationException.Message);
                }

                return;
            }

            var modernBrowser = sender as WebView2;
            if (modernBrowser == null || modernBrowser.CoreWebView2 == null)
            {
                return;
            }

            modernBrowser.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            modernBrowser.CoreWebView2.Settings.AreDevToolsEnabled = false;
            modernBrowser.CoreWebView2.Settings.IsZoomControlEnabled = true;
            modernBrowser.CoreWebView2.NewWindowRequested += CoreWebView2OnNewWindowRequested;
        }

        private void ModernBrowserOnNavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs eventArgs)
        {
            statusLabel.Text = "Opening page...";
            progressBar.Visible = true;
            progressBar.Value = 0;
        }

        private void ModernBrowserOnNavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs eventArgs)
        {
            var modernBrowser = sender as WebView2;
            if (modernBrowser == null)
            {
                return;
            }

            UpdateModernTabTitle(modernBrowser);
            statusLabel.Text = eventArgs.IsSuccess ? "Done" : "Navigation failed";
            progressBar.Visible = false;
            progressBar.Value = 0;
            addressBox.Text = modernBrowser.Source != null ? modernBrowser.Source.ToString() : addressBox.Text;
            UpdateNavButtons();
        }

        private void ModernBrowserOnSourceChanged(object sender, CoreWebView2SourceChangedEventArgs eventArgs)
        {
            var modernBrowser = sender as WebView2;
            if (modernBrowser == null)
            {
                return;
            }

            if (tabControl.SelectedTab != null && tabControl.SelectedTab.Controls.Contains(modernBrowser))
            {
                addressBox.Text = modernBrowser.Source != null ? modernBrowser.Source.ToString() : string.Empty;
            }
        }

        private void CoreWebView2OnNewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs eventArgs)
        {
            eventArgs.Handled = true;
            Uri uri;
            if (Uri.TryCreate(eventArgs.Uri, UriKind.Absolute, out uri))
            {
                OpenModernTab(uri);
            }
        }

        private void TabControlOnSelectedIndexChanged(object sender, EventArgs eventArgs)
        {
            var modernBrowser = GetActiveModernBrowser();
            if (modernBrowser != null)
            {
                addressBox.Text = modernBrowser.Source != null ? modernBrowser.Source.ToString() : string.Empty;
            }
            else
            {
                addressBox.Text = browser.Url != null ? browser.Url.ToString() : settings.HomePage;
            }

            UpdateNavButtons();
        }

        private WebView2 GetActiveModernBrowser()
        {
            if (tabControl.SelectedTab == null || tabControl.SelectedTab == legacyTabPage)
            {
                return null;
            }

            if (tabControl.SelectedTab.Controls.Count == 0)
            {
                return null;
            }

            return tabControl.SelectedTab.Controls[0] as WebView2;
        }

        private void UpdateModernTabTitle(WebView2 modernBrowser)
        {
            if (modernBrowser.Parent == null)
            {
                return;
            }

            var pageTitle = modernBrowser.CoreWebView2 != null && !string.IsNullOrWhiteSpace(modernBrowser.CoreWebView2.DocumentTitle)
                ? modernBrowser.CoreWebView2.DocumentTitle
                : "Modern Tab";

            modernBrowser.Parent.Text = pageTitle;
            Text = pageTitle + " - Windows Internet Explorer";
        }

        private static bool LooksLikeHostName(string input)
        {
            return input.IndexOf(' ') < 0 &&
                (input.IndexOf('.') >= 0 ||
                 input.Equals("localhost", StringComparison.OrdinalIgnoreCase));
        }

        private static bool LooksLikeLocalFile(string input)
        {
            return input.StartsWith(@"\\", StringComparison.OrdinalIgnoreCase) ||
                (input.Length > 2 && char.IsLetter(input[0]) && input[1] == ':' &&
                 (input[2] == '\\' || input[2] == '/'));
        }

        private void ExecuteDocumentCommand(string command)
        {
            var document = browser.Document;
            if (document == null)
            {
                return;
            }

            document.ExecCommand(command, false, null);
        }

        private void ShowAbout()
        {
            const string message =
                "Internet Explorer REBORN\n" +
                "Version: " + VersionLabel + "\n" +
                "Inspired by the 2006-era Internet Explorer shell.\n\n" +
                "This recreation is built as a standalone Windows executable.";

            MessageBox.Show(this, message, "About Internet Explorer", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowInfo(string title, string message)
        {
            MessageBox.Show(this, message, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    internal sealed class InternetExplorerRenderer : ToolStripProfessionalRenderer
    {
        public InternetExplorerRenderer() : base(new InternetExplorerColorTable())
        {
            RoundedEdges = false;
        }

        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            var bounds = new Rectangle(Point.Empty, e.ToolStrip.Size);
            using (var brush = new LinearGradientBrush(bounds, Color.FromArgb(197, 201, 206), Color.FromArgb(251, 252, 254), LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, bounds);
            }

            using (var pen = new Pen(Color.FromArgb(145, 149, 154)))
            {
                e.Graphics.DrawLine(pen, 0, bounds.Bottom - 1, bounds.Right, bounds.Bottom - 1);
            }
        }

        protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
        {
            var bounds = new Rectangle(Point.Empty, e.Item.Size);
            var button = e.Item as ToolStripButton;
            var pressed = button != null && button.Pressed;
            var selected = e.Item.Selected;

            if (pressed || selected)
            {
                var start = pressed ? Color.FromArgb(188, 205, 226) : Color.FromArgb(226, 235, 246);
                var end = pressed ? Color.FromArgb(143, 168, 198) : Color.FromArgb(184, 206, 229);

                using (var brush = new LinearGradientBrush(bounds, start, end, LinearGradientMode.Vertical))
                {
                    e.Graphics.FillRectangle(brush, bounds);
                }

                using (var pen = new Pen(Color.FromArgb(120, 145, 171)))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, bounds.Width - 1, bounds.Height - 1);
                }
            }
            else
            {
                base.OnRenderButtonBackground(e);
            }
        }
    }

    internal sealed class InternetExplorerColorTable : ProfessionalColorTable
    {
        public override Color MenuStripGradientBegin
        {
            get { return Color.FromArgb(197, 201, 206); }
        }

        public override Color MenuStripGradientEnd
        {
            get { return Color.FromArgb(251, 252, 254); }
        }

        public override Color ToolStripGradientBegin
        {
            get { return Color.FromArgb(197, 201, 206); }
        }

        public override Color ToolStripGradientMiddle
        {
            get { return Color.FromArgb(228, 232, 237); }
        }

        public override Color ToolStripGradientEnd
        {
            get { return Color.FromArgb(251, 252, 254); }
        }

        public override Color StatusStripGradientBegin
        {
            get { return Color.FromArgb(230, 232, 236); }
        }

        public override Color StatusStripGradientEnd
        {
            get { return Color.FromArgb(247, 248, 250); }
        }
    }
}
